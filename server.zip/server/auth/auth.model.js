const mongoose = require('mongoose');
const Schema = mongoose.Schema;
mongoose.set('useCreateIndex', true)//indexes also created
const userSchema = new Schema ({
    name: {type: String, required: true, trim:true},
    email: {type: String, required: true, trim:true, unique:true},
    password: {type: String, required: true, trim: true}
},
{
    timestamps: true//created date and time also done
});

module.exports = userSchema;