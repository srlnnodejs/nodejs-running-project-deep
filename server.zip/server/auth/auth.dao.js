const mongoose = require('mongoose');
const authSchema = require('./auth.model');


authSchema.statics = {
    create: function(data, cb)
    {
        const user = new this(data)
        console.log("comingdatas are"+data);
        user.save(cb);
    },
    login: function(query, cb)//function oculta
    {
        console.log("coming query are"+query);
        this.find(query, cb);
    
    }
}

const authModel = mongoose.model('Users', authSchema);
module.exports = authModel;