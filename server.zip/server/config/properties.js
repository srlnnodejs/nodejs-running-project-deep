module.exports = {
    PORT: process.env.PORT || 3000,
    DB: 'mongodb://localhost:27017/LoginMEAN'
}